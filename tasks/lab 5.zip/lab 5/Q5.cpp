#include<iostream>

using namespace std;



int main()

{   


   int a=9;
   int *ptr=&a;
   cout<<"value by a pointer :"<<*ptr<<endl;
   cout<<"address of a value :"<<ptr<<endl;




   return 0;

       
    
}
